make the TODOS with the functionality mention below
Get Todos API: https://jsonplaceholder.typicode.com/todos
Create a frontend app, with following tasks:

Task 1: - Fetch todos and show it in a list.  
 - Each element of the list, show title and todo status(using a checkbox). -
Task 2:  
 - User should be able to update the status of todo, via checking or unchecking the checkbox(no need to call the api, changes needs to be saved locally).

Task 3: - Make a counter which will count the total number of true and false values

Note :-
you will have to complete this task by using Key
