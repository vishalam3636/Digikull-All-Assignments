import React from "react";

class Footer extends React.Component {
  constructor() {
    super();
  }

  render() {
    return (
      <div className="mainContainer footer">
        <h3>@2022 TIP-CALCULATOR</h3>
      </div>
    );
  }
}

export default Footer;
